<!DOCTYPE html>
<html>
<head> 

<meta charset="utf-8"> 
<title>Overseas Student Recruitment management</title> 
<link rel="stylesheet" href="<?php echo e(asset('css/shiyishi.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

</head>
<body>
 
<div id="header" style="background-color:#fff;"><br>
    <div class="text-right links font">
        <a href="<?php echo e(route('login')); ?>">Login</a>
        <a href="<?php echo e(route('register')); ?>">Register</a>
    </div>
</div>
 
<div class="row"> 
<div class="col-md-6">
                <div class="title m-b-md"><br>
                    <a>
                    <img src="<?php echo e(URL::asset('/images/TUOS_Logo_CMYK.png')); ?>" alt="profile Pic" height="200" style="margin-left: 32%;" >
                    </a>
                    <br>

                    <div class="text-center font">
                    <span style="font-size:70px;">
                    Overseas Student Recruitment management System
                    </span></div>
                </div>
</div>

 
<div  class="col-md-6 font" style="margin-top: 20%">
    <div class="content" >
        <div class="row ">
                    <div>
                        <span style="font-weight;font-size:80px;color: black;">Welcome</span>
                    </div>
                    <br>
                        <p>
                            This Overseas Student Management System can help teachers dealiing with problems. <br>
                            Provided by: Mark, Daneil, Harry and Bing.
                        </p>
        </div>
    </div>
</div>
</div>
 
</body>

<footer>
        <div class="text-center font" style="margin-top: 8%">
                <p>Uniersity of Sheffield/ Conmputer of Science/ Software System of Internet Technology/ Maxi Project/ Team Three </p> 
        </div>
</footer> 

</html>




<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8"> 
        <title>Teacher-Stu Interface</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/shiyishi.css')); ?>">

</head>

<body>
        
<div style="">
        <div id="header" style="background-color:#fff;">
                <div class="text-right links"><br>
                        <a href="<?php echo e(url('/main')); ?>">Main</a>
                </div>
</div>

        <div id=header class="">
                <div class="col-md-4">
                        <a><img src="<?php echo e(URL::asset('/images/TUOS_Logo_CMYK.png')); ?>" alt="profile Pic" height="200" style="margin-left: 13%;" ></a>
                </div>
                <div class="col-md-8">
                        <div class="text-center" style="font-size: 50px; margin-top:5%">
                                <h><strong>Overseas Student Recruitment management</strong></h>
                        </div>
                </div>
        </div>
        
        <div class="col-md-12">
                <div class="text-right links" style="background-color: #66B3FF">
                        <button type="button" style="color:white" class="btn btn-link">Upload File</button>
                        <a href="<?php echo e(url('/emailmodify')); ?>"><button type="button" style="color:white" class="btn btn-link"  >Email Modification</button></a>
                        <button type="button" style="color:white" class="btn btn-link">Feedback</button>
                </div>
        </div>

        <div class="text-center col-md-12">
                <br><span style="font-size:45px;">Enquireies</span>
        </div>

        <form action="/insert" method="post">

                <?php echo e(csrf_field()); ?>


                <div style="margin-left: 30%"><br><br>
                        <div class="row col-md-10">
                                
                                <div class="col-md-3">
                                <span style="font-size:20px;">First Name</span><br>
                                <input class="form-control" input class="form-control" value="<?php echo e($students->first_name); ?>" disabled><br></div>

                                <div class="col-md-3">
                                 <span style="font-size:20px;">Middle name</span><br/>
                                <input class="form-control" input class="form-control" value="<?php echo e($students->middle_name); ?>" disabled><br/></div>

                                <div class="col-md-3">
                                <span style="font-size:20px;">Surname</span><br/>
                                <input class="form-control" input class="form-control" value="<?php echo e($students->last_name); ?>" disabled><br/></div>
                   
                        </div>
         
                </div>


                <div  style="margin-left: 29%" class="col-md-7">
                        <div  class="col-md-9 ">

                        <span style="font-size:20px;">Nationality</span><br/>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->nationality); ?>" disabled><br/>

                        <span style="font-size:20px;">Meeting Place</span><br/>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->place); ?>" disabled><br/>
                        </div>
                </div>

                <div  style="margin-left: 29%" class="col-md-7">
                        <div  class="col-md-9 ">
                        <span style="font-size:20px;">Date</span>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->date); ?>" disabled><br>


                        <span style="font-size:20px;">Email Address</span>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->email); ?>" disabled><br>

                       

                        <span style="font-size:20px;">Level of Study</span><br>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->level); ?>" disabled><br>


                        <span style="font-size:20px;">Department</span><br>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->department); ?>" disabled><br>

                        <span style="font-size:20px;">Course/Subject</span><br>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->course); ?>" disabled><br>

                        <span style="font-size:20px;">Telephone Number</span>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->phone_number); ?>" disabled><br>

                        <span style="font-size:20px;" type="text" name="start_year" >Which Year You Want To Start</span>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->start_year); ?>" disabled><br>

                        <span style="font-size:20px;"  >Have You Already Applied ?</span>&emsp;&emsp;&emsp;&emsp;
                        <span style="font-size:15px;">Yes</span>&emsp;
                        <?php if($students->is_special == 1): ?>
                        <label><input type="checkbox" checked disabled></label>
                        <?php else: ?>
                        <label><input type="checkbox" disabled></label>
                       <?php endif; ?>
                        <span style="font-size:15px;">No</span>&emsp;
                        <?php if($students->is_special == 0): ?>
                        <label><input type="checkbox" checked disabled></label>
                        <?php else: ?>
                        <label><input type="checkbox" disabled></label>
                        <?php endif; ?>
 
                        <br>
                        <span style="font-size:20px;">If Yes, Input Your Regesition Number</span>
                        <?php if($students->is_special == 1): ?>
                        <input class="form-control" input class="form-control" value="<?php echo e($students->regesition_number); ?>" disabled><br>
                        <?php else: ?>
                        <input class="form-control" input class="form-control" disabled><br>
                        <?php endif; ?>

                        <span style="font-size:20px;">Specific Question</span>
                        <input class="form-control" value="<?php echo e($students->questions); ?>" disabled>

                        <span style="font-size:15px;">Send now? </span>&emsp;
                        <input type="checkbox" checked><br/><br><br>


                        <div class="text-center links"><br>
                                <a href="<?php echo e(url('/main')); ?>">Back To Main</a>
                        </div><br><br>
                </div>
                </div>

                
</form>
</div>



</body>
                



</html>



<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home1', function() {
	return view('welcome');
});

Route::get('/enquireies', function() {
	return view('enquireies');
});

Auth::routes();

Route::get('/home', 'StudentController@show');

Route::group(['middleware' => 'auth',], function () {
	Route::get('/main', 'StudentController@show');
	Route::get('/student', 'StudentController@showEnquireies');
	Route::get('/details/{id}', 'StudentController@showDetail');
	Route::post('/student', 'StudentController@storeStudent');
	Route::put('/student', 'StudentController@modifyStudent');
	Route::get('/main/{key}/{value}', 'StudentController@searchStudent');
});


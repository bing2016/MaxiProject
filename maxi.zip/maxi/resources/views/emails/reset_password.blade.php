Dear {{$name}},
<br/><br/>
Hello, now you can reset your password by clicking the link below:
<br/><br/>
www.google.com
<br/><br/>
Please be careful with your new password. Thank you.
<br/><br/>
Best regards,<br/>
Maxi Project Team
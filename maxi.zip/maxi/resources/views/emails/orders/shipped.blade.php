Dear {{$first_name}}
<br/><br/>
You have choosen {{$department}}. Your nationality is {{$nationality}}.
<br/><br/>
Thank you.
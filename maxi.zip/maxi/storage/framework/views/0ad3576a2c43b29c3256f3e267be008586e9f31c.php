Dear <?php echo e($name); ?>,<br/>
<br/>
Thank you for coming to speak with the University of Sheffield recently. I hope you found the discussion enjoyable, interesting and informative. This e-mail contains information about your subject area, the University itself and advice on funding options.<br/>
<br/>
You expressed a particular interest in our <?php echo e($department); ?>.  You can find more information about the relevant programme(s) here: <?php echo e($nationality); ?>.<br/>
<br/>
«blurb»<br/>
<br/>
*The University of Sheffield*<br/>
As a place to study at, Sheffield offers both the highest academic quality and a great lifestyle. The University is consistently ranked in the World Top 100 - the QS Rankings 2016-17 position Sheffield at number 84. Sheffield was a founding member of the Russell Group – the Ivy League of UK universities - and we’re proud to have had 6 Nobel Prizes for former staff or students.<br/>
<br/>
In terms of lifestyle, Sheffield is statistically the safest and one of the cheapest cities in the UK for students to live in. It’s also the UK’s greenest city and The Peak District, the oldest national park in the UK, is only 10 minutes' drive from the University. Sheffield was No 3 in the UK in the survey of ‘Student Experience 2016’ carried out by the Times Higher Education publication. This survey measures the students’ assessment of their university across a range of academic, social and environmental parameters. In the same survey, our Student’s Union (the heart of social life on campus) has been voted Number 1 in the UK for the last 9 years.<br/>
<br/>
*Fees and Scholarships*<br/>
Tuition fees can be found here: https://www.sheffield.ac.uk/ssid/fees/pgt/lookup (select your department and then overseas). Please note - this page will be updated soon for 2017 fees.
<br/><br/>
We are pleased to offer a range of scholarships specifically to students from Brazil.  We have automatic scholarships worth £2000-£2500, merit based scholarships worth 50% of the tuition fee and also Santander scholarships worth £5000 for both undergraduate and postgraduate students.<br/>
<br/>
You may also wish to apply for a Chevening scholarship for study at Sheffield: http://www.chevening.org/brazil.  Please note the application deadline for Chevening is 8 November.<br/>
<br/>
*How to Apply* <br/>
The application is done through our website: http://www.sheffield.ac.uk/postgraduate/taught/apply/applying.   <br/>
<br/>
I do hope that you have found this information helpful. If you cannot find what you are looking for, please do not hesitate to contact me and I will get back to you. We are here to help.
<br/><br/>
Best wishes,<br/>
--<br/>
Ruth Lauener<br/>
International Officer<br/>
Global Engagement<br/>
The University of Sheffield<br/>
Level 1, The Arts Tower<br/>
Western Bank<br/>
Sheffield<br/>
S10 2TN<br/>
Tel: +44(0)114 222 8025<br/>
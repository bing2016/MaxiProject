<?php echo e($welcomenew); ?>

<br/>
<?php echo e($applynew); ?>